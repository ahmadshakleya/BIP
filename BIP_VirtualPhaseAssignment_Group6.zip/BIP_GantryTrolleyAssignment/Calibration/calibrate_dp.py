import os
from animation import readMat
import pandas as pd
import numpy as np

# Function to run a single simulation
def single_simulation(dp):
    simulation_command = f"./GantryTrolley_TrolleyLockSimulation-override
    gantryTrolley_PendulumLock.dp={dp}"
    os.system(simulation_command)
    [names, data] = readMat("GantryTrolley_TrolleyLockSimulation_res.mat")
    return [names, data]

# Load calibration data
df = pd.read_csv("../calibration_data_d_p.csv", header=0, names=['theta_array (angular position)'])
measured_values = df.iloc[:, 0].to_numpy()

# Function to calculate SSE
def calculate_sse(simulated, measured):
    return np.sum((simulated- measured) ** 2)

# Sweep over possible values of dp
sse_dp_list = []
for dp in np.arange(0, 5, 0.01):
    [names, data] = single_simulation(dp)
    theta_index = names.index("gantryTrolley_TrolleyLock.x")
    theta_array = data[theta_index]
    sse = calculate_sse(theta_array, measured_values)
    sse_dp_list.append(sse)

# Find optimal dp
optimal_dp = 0 + np.argmin(sse_dp_list) * 0.01
print(f"Optimal dp: {optimal_dp}")