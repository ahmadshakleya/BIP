import os
from animation import readMat
import pandas as pd
import numpy as np

# Function to run a single simulation
def single_simulation(dc):
    simulation_command = f"./GantryTrolley_PendulumLockSimulation-override
    gantryTrolley_PendulumLock.dc={dc}"
    os.system(simulation_command)
    [names, data] = readMat("GantryTrolley_PendulumLockSimulation_res.mat")
    return [names, data]

# Load calibration data
df = pd.read_csv("../calibration_data_d_c.csv", header=0, names=['x_array (position)'])
measured_values = df.iloc[:, 0].to_numpy()

# Function to calculate SSE
def calculate_sse(simulated, measured):
    return np.sum((simulated- measured) ** 2)

# Sweep over possible values of dc
sse_dc_list = []
for dc in np.arange(0, 5, 0.01):
    [names, data] = single_simulation(dc)
    x_index = names.index("gantryTrolley_PendulumLock.x")
    x_array = data[x_index]
    sse = calculate_sse(x_array, measured_values)
    sse_dc_list.append(sse)

# Find optimal dc
optimal_dc = 0 + np.argmin(sse_dc_list) * 0.01
print(f"Optimal dc: {optimal_dc}")